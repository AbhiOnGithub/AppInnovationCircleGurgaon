﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIs.Models;

namespace APIs
{
    public class ProductRepository : IProductRepository
    {
        IList<Product> products = new List<Product>();

        public void Add(Product product)
        {
            products.Add(product);
        }

        public void Delete(int id)
        {
            
        }

        public Product Get(int id)
        {
            var product = products.FirstOrDefault((p) => p.Id == id);
            if (product == null)
            {
                return null;
            }
            return product;
        }

        public IList<Product> GetAll()
        {
            return products;
        }

        public void Update(Product product)
        {
            throw new NotImplementedException();
        }
    }
}
