﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APIs.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace APIs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private IProductRepository products;

        public ProductsController(IProductRepository repository)
        {
            products = repository;
        }

        // GET api/Products
        [HttpGet]
        public ActionResult<IList<Product>> Get()
        {
            return Ok(products.GetAll());
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<Product> Get(int id)
        {
            var product = products.Get(id);
            if (product == null)
                return NotFound();
            return Ok(product);
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] Product product)
        {
            products.Add(product);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Product product)
        {
            
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            
        }
    }
}